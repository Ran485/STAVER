"""Top-level package for STAVER."""

__author__ = """PengRan"""
__email__ = '2502388440@qq.com'
__version__ = '0.1.0'
