API documentation
=================

This section provides detailed API documentation for all public functions
and classes in ``staver``.

.. autosummary::
   :toctree: api
   :template: module.rst
   :recursive:

   staver
