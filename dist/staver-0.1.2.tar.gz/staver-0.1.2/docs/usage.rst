=====
Usage
=====

To use STAVER in a project::

    import staver
